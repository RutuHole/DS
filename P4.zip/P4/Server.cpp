#include <iostream>
#include <iomanip>
#include <cstdlib>
#include <unistd.h>
#include <stdio.h>
#include <sys/socket.h>
#include <stdlib.h>
#include <netinet/in.h>
#include <string.h>
#include <arpa/inet.h>
#include <vector>
#include <ctime>

#define PORT 8080

using namespace std;

vector<string> split(string s, string delimiter)
{
    size_t pos_start = 0, pos_end, delim_len = delimiter.length();
    string token;
    vector<string> res;

    while ((pos_end = s.find(delimiter, pos_start)) != string::npos)
    {
        token = s.substr(pos_start, pos_end - pos_start);
        pos_start = pos_end + delim_len;
        res.push_back(token);
    }

    res.push_back(s.substr(pos_start));
    return res;
}

int main(int argc, char *argv[])
{
    srand((unsigned int)time(NULL));

    float server_local_clock = rand() % 10;

    vector<float> clients_local_clocks;
    vector<int> client_sockets;
    vector<string> client_ips;
    vector<int> client_ports;

    printf("Server starts. PID: %d\n", getpid());
    printf("Server local clock: %f\n\n", server_local_clock);

    int server_socket_fd, new_socket;
    struct sockaddr_in server_address;

    server_address.sin_family = AF_INET;
    server_address.sin_addr.s_addr = INADDR_ANY;
    server_address.sin_port = htons(PORT);

    int opt = 1;

    if ((server_socket_fd = socket(AF_INET, SOCK_STREAM, 0)) == 0)
    {
        perror("Socket failed");
        exit(EXIT_FAILURE);
    }

    setsockopt(server_socket_fd, SOL_SOCKET, SO_REUSEADDR | SO_REUSEPORT, &opt, sizeof(opt));

    if (bind(server_socket_fd, (struct sockaddr *)&server_address, sizeof(server_address)) < 0)
    {
        perror("Bind failed");
        exit(EXIT_FAILURE);
    }

    if (listen(server_socket_fd, 7) < 0)
    {
        perror("Listen failed");
        exit(EXIT_FAILURE);
    }

    printf("Server listening...\n");

    int clients_ctr = 0;
    int in_client_enough = 0;

    while (in_client_enough == 0)
    {
        struct sockaddr_in client_addr;
        socklen_t length = sizeof(client_addr);

        new_socket = accept(server_socket_fd, (struct sockaddr *)&client_addr, &length);

        clients_ctr++;

        char client_ip[INET_ADDRSTRLEN];
        inet_ntop(AF_INET, &client_addr.sin_addr, client_ip, INET_ADDRSTRLEN);

        printf("Client %d connected: %s:%d\n",
               clients_ctr,
               client_ip,
               ntohs(client_addr.sin_port));

        client_sockets.push_back(new_socket);
        client_ips.push_back(client_ip);
        client_ports.push_back(ntohs(client_addr.sin_port));

        cout << "Enough clients? (1=yes, 0=no): ";
        cin >> in_client_enough;
    }

    printf("\nTotal clients: %d\n", (int)client_sockets.size());

    char recv_buf[65536];

    for (int i = 0; i < client_sockets.size(); i++)
    {
        const char *msg = "Hello from server, send your local clock";
        send(client_sockets[i], msg, strlen(msg), 0);

        recv(client_sockets[i], recv_buf, sizeof(recv_buf), 0);

        string recv_msg = string(recv_buf);

        vector<string> split_str = split(recv_msg, " ");
        string clock_str = split_str.back();

        float client_clock = stof(clock_str);

        clients_local_clocks.push_back(client_clock);

        printf("Client clock received: %f\n", client_clock);

        memset(recv_buf, 0, sizeof(recv_buf));
    }

    float sum = server_local_clock;

    for (float c : clients_local_clocks)
        sum += c;

    float avg = sum / (clients_local_clocks.size() + 1);

    for (int i = 0; i < client_sockets.size(); i++)
    {
        float offset = clients_local_clocks[i] - avg;

        string op = (offset >= 0) ? "minus" : "add";
        if (offset < 0) offset = -offset;

        string msg = "Adjust clock " + op + " " + to_string(offset);

        send(client_sockets[i], msg.c_str(), msg.length(), 0);

        printf("Sent to client %d: %s\n", i + 1, msg.c_str());
    }

    server_local_clock += (avg - server_local_clock);

    printf("\nNew server clock: %f\n", server_local_clock);

    close(server_socket_fd);

    return 0;
}  
