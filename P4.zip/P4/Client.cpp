#include <stdio.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <unistd.h>
#include <string.h>
#include <iostream>
#include <cstdlib>
#include <ctime>
#include <vector>

#define PORT 8080

using namespace std;

vector<string> split(string s, string delimiter)
{
    size_t pos_start = 0, pos_end, delim_len = delimiter.length();
    string token;
    vector<string> res;

    while ((pos_end = s.find(delimiter, pos_start)) != string::npos)
    {
        token = s.substr(pos_start, pos_end - pos_start);
        pos_start = pos_end + delim_len;
        res.push_back(token);
    }

    res.push_back(s.substr(pos_start));
    return res;
}

int main(int argc, char const *argv[])
{
    srand((unsigned int)time(NULL));

    float client_local_clock = rand() % 10;

    printf("Client starts. PID: %d\n", getpid());
    printf("Client local clock: %f\n\n", client_local_clock);

    int client_socket_fd;
    int valread;

    char client_read_buffer[1024] = {0};

    struct sockaddr_in server_addr;

    server_addr.sin_family = AF_INET;
    server_addr.sin_port = htons(PORT);

    if ((client_socket_fd = socket(AF_INET, SOCK_STREAM, 0)) < 0)
    {
        printf("Socket creation error\n");
        return -1;
    }

    if (inet_pton(AF_INET, "127.0.0.1", &server_addr.sin_addr) <= 0)
    {
        printf("Invalid address\n");
        return -1;
    }

    if (connect(client_socket_fd, (struct sockaddr *)&server_addr, sizeof(server_addr)) < 0)
    {
        printf("Connection Failed\n");
        return -1;
    }

    printf("Client connected to server\n\n");

    // ---------------- FIRST MESSAGE ----------------
    read(client_socket_fd, client_read_buffer, 1024);

    printf("Client received: %s\n", client_read_buffer);

    string msg1(client_read_buffer);

    if (msg1.find("Hello from server") != string::npos)
    {
        string send_msg = "Hello from client, my local clock value is " +
                          to_string(client_local_clock);

        send(client_socket_fd, send_msg.c_str(), send_msg.length(), 0);

        printf("Client sent: %s\n", send_msg.c_str());
    }

    memset(client_read_buffer, 0, sizeof(client_read_buffer));

    // ---------------- SECOND MESSAGE ----------------
    valread = read(client_socket_fd, client_read_buffer, 1024);

    string msg2(client_read_buffer);

    printf("Client received: %s\n", client_read_buffer);

    if (msg2.find("clock adjustment offset") != string::npos)
    {
        vector<string> split_str = split(msg2, " ");

        string operation = split_str[split_str.size() - 2];
        float offset = stof(split_str[split_str.size() - 1]);

        if (operation == "add")
        {
            client_local_clock += offset;
        }
        else if (operation == "minus")
        {
            client_local_clock -= offset;
        }

        printf("Updated client clock: %f\n", client_local_clock);
    }

    close(client_socket_fd);

    return 0;
}
