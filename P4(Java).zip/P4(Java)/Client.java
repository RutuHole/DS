import java.io.*;
import java.net.*;
import java.util.*;

public class Client {

    static final int PORT = 8080;

    public static void main(String[] args) {

        Random random = new Random();

        float clientClock = random.nextInt(10);

        System.out.println("Client Started");
        System.out.println("Client Local Clock: " + clientClock + "\n");

        try {
            Socket socket = new Socket("localhost", PORT);

             BufferedReader in = new BufferedReader(
                    new InputStreamReader(socket.getInputStream()));

            PrintWriter out = new PrintWriter(socket.getOutputStream(), true);

            String serverMsg = in.readLine();

            System.out.println("Message From Server: " + serverMsg);

            out.println("My clock is " + clientClock);

            System.out.println("Clock Sent To Server");

            String offsetStr = in.readLine();

            float offset = Float.parseFloat(offsetStr);

            System.out.println("Offset Received: " + offset);

            clientClock += offset;

            System.out.println("Updated Client Clock: " + clientClock);

            socket.close();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}