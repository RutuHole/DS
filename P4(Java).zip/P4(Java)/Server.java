import java.io.*;
import java.net.*;
import java.util.*;

public class Server {

    static final int PORT = 8080;

    public static void main(String[] args) {

        Random random = new Random();
        float serverClock = random.nextInt(10);

        ArrayList<Socket> clients = new ArrayList<>();
        ArrayList<Float> clientClocks = new ArrayList<>();

        System.out.println("Server Started");
        System.out.println("Server Local Clock: " + serverClock + "\n");

                try {
            ServerSocket serverSocket = new ServerSocket(PORT);
            Scanner sc = new Scanner(System.in);

            int choice = 0;

            while (choice == 0) {
                Socket socket = serverSocket.accept();

                System.out.println("Client Connected: " + socket.getInetAddress());

                clients.add(socket);

                System.out.print("Enough Clients? (1 = Yes, 0 = No): ");
                choice = sc.nextInt();
            }

         for (Socket socket : clients) {

                PrintWriter out = new PrintWriter(socket.getOutputStream(), true);
                BufferedReader in = new BufferedReader(
                        new InputStreamReader(socket.getInputStream()));

                out.println("Send your local clock");

                String msg = in.readLine();

                System.out.println("Received From Client: " + msg);

                String[] parts = msg.split(" ");

                float clientClock = Float.parseFloat(parts[parts.length - 1]);

                clientClocks.add(clientClock);
            }

            float sum = serverClock;
             for (float c : clientClocks) {
                sum += c;
            }

            float average = sum / (clientClocks.size() + 1);

            System.out.println("\nAverage Clock Value: " + average);

            for (int i = 0; i < clients.size(); i++) {

                Socket socket = clients.get(i);

                PrintWriter out = new PrintWriter(socket.getOutputStream(), true);

                float offset = average - clientClocks.get(i);

                out.println(offset);

                System.out.println("Sent Offset To Client " + (i + 1)
                        + ": " + offset);
            }

            serverClock = average;

            System.out.println("\nUpdated Server Clock: " + serverClock);

            serverSocket.close();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}