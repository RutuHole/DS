import java.io.*;

class BullyAlgo
{
    int cood, ch, crash;
    int prc[];

    public void election(int n) throws IOException
    {
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));

        System.out.println("\nThe Coordinator Has Crashed!");

        int flag = 1;

        while(flag == 1)
        {
            crash = 0;

            for(int i1 = 0; i1 < n; i1++)
                if(prc[i1] == 0)
                    crash++;

            if(crash == n)
            {
                System.out.println("\n*** All Processes Are Crashed ***");
                break;
            }
            else
            {
                System.out.println("\nEnter The Initiator: ");
                int init = Integer.parseInt(br.readLine());

                if((init < 1) || (init > n) || (prc[init - 1] == 0))
                {
                    System.out.println("\nInvalid Initiator");
                    continue;
                }

                for(int i1 = init - 1; i1 < n; i1++)
                    System.out.println("Process " + (i1 + 1) + " called for election");

                for(int i1 = init - 1; i1 < n; i1++)
                {
                    if(prc[i1] == 0)
                        System.out.println("Process " + (i1 + 1) + " is dead");
                    else
                        System.out.println("Process " + (i1 + 1) + " is active");
                }

                for(int i1 = n - 1; i1 >= 0; i1--)
                {
                    if(prc[i1] == 1)
                    {
                        cood = (i1 + 1);
                        System.out.println("\n*** New Coordinator is " + cood + " ***");
                        flag = 0;
                        break;
                    }
                }
            }
        }
    }

    public void Bully() throws IOException
    {
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));

        System.out.println("Enter The Number Of Processes: ");
        int n = Integer.parseInt(br.readLine());

        prc = new int[n];

        for(int i = 0; i < n; i++)
            prc[i] = 1;

        cood = n;

        do
        {
            System.out.println("\n1. Crash A Process");
            System.out.println("2. Recover A Process");
            System.out.println("3. Display Coordinator");
            System.out.println("4. Exit");

            ch = Integer.parseInt(br.readLine());

            switch(ch)
            {
                case 1:
                {
                    System.out.println("\nEnter Process to Crash:");
                    int cp = Integer.parseInt(br.readLine());

                    if((cp < 1) || (cp > n))
                    {
                        System.out.println("Invalid Process!");
                    }
                    else if((prc[cp - 1] == 1) && (cood != cp))
                    {
                        prc[cp - 1] = 0;
                        System.out.println("Process " + cp + " crashed");
                    }
                    else if((prc[cp - 1] == 1) && (cood == cp))
                    {
                        prc[cp - 1] = 0;
                        election(n);
                    }
                    else
                    {
                        System.out.println("Process already crashed");
                    }
                    break;
                }

                case 2:
                {
                    System.out.println("\nEnter Process to Recover:");
                    int rp = Integer.parseInt(br.readLine());

                    if((rp < 1) || (rp > n))
                    {
                        System.out.println("Invalid Process");
                    }
                    else if(prc[rp - 1] == 0)
                    {
                        prc[rp - 1] = 1;
                        System.out.println("Process " + rp + " recovered");

                        if(rp > cood)
                        {
                            cood = rp;
                            System.out.println("Process " + rp + " is new coordinator");
                        }
                    }
                    else
                    {
                        System.out.println("Process is already active");
                    }
                    break;
                }

                case 3:
                {
                    System.out.println("\nCurrent Coordinator is " + cood);
                    break;
                }

                case 4:
                    System.exit(0);

                default:
                    System.out.println("Invalid Choice");
            }
        }
        while(ch != 4);
    }

    public static void main(String args[]) throws IOException
    {
        BullyAlgo ob = new BullyAlgo();
        ob.Bully();
    }
}
