import java.util.Scanner;

class Rr
{
    public int index;
    public int id;
    public int f;
    String state;
}

public class Ring
{
    public static void main(String[] args)
    {
        int i, j, temp;

        Rr proc[] = new Rr[10];

        for(i = 0; i < proc.length; i++)
            proc[i] = new Rr();

        Scanner in = new Scanner(System.in);

        System.out.println("Enter number of processes: ");
        int num = in.nextInt();

        for(i = 0; i < num; i++)
        {
            proc[i].index = i;

            System.out.println("Enter process id: ");
            proc[i].id = in.nextInt();

            proc[i].state = "active";
            proc[i].f = 0;
        }

        // sort by id
        for(i = 0; i < num - 1; i++)
        {
            for(j = 0; j < num - 1; j++)
            {
                if(proc[j].id > proc[j + 1].id)
                {
                    temp = proc[j].id;
                    proc[j].id = proc[j + 1].id;
                    proc[j + 1].id = temp;
                }
            }
        }

        for(i = 0; i < num; i++)
            System.out.print(" [" + i + "] " + proc[i].id);

        proc[num - 1].state = "inactive";
        System.out.println("\nProcess " + proc[num - 1].id + " selected as coordinator");

        while(true)
        {
            System.out.println("\n1. Election  2. Quit");
            int ch = in.nextInt();

            for(i = 0; i < num; i++)
                proc[i].f = 0;

            switch(ch)
            {
                case 1:
                {
                    int k = 0;
                    int arr[] = new int[10];

                    System.out.println("Enter process initiating election (index 0 to " + (num-1) + "): ");
                    int init = in.nextInt();

                    if(init < 0 || init >= num)
                    {
                        System.out.println("Invalid initiator");
                        break;
                    }

                    int start = init;
                    int temp1 = (init + 1) % num;

                    while(temp1 != start)
                    {
                        if(proc[temp1].state.equals("active") && proc[temp1].f == 0)
                        {
                            System.out.println("Process " + proc[start].id +
                                    " sends message to " + proc[temp1].id);

                            proc[temp1].f = 1;
                            start = temp1;

                            arr[k++] = proc[temp1].id;
                        }

                        temp1 = (temp1 + 1) % num;
                    }

                    System.out.println("Process " + proc[start].id +
                            " sends message to " + proc[temp1].id);

                    arr[k++] = proc[temp1].id;

                    int max = -1;

                    for(j = 0; j < k; j++)
                        if(arr[j] > max)
                            max = arr[j];

                    System.out.println("Process " + max + " selected as coordinator");

                    for(i = 0; i < num; i++)
                        if(proc[i].id == max)
                            proc[i].state = "inactive";

                    break;
                }

                case 2:
                    System.out.println("Program terminated...");
                    return;

                default:
                    System.out.println("Invalid choice");
            }
        }
    }
}
