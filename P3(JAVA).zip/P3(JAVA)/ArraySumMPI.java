import mpi.*;

public class ArraySumMPI {
    public static void main(String[] args) throws Exception {

        MPI.Init(args);

        int rank = MPI.COMM_WORLD.Rank();
        int size = MPI.COMM_WORLD.Size();

        int[] num = new int[20];
        int[] recvArray = new int[5];
        int[] localSum = new int[1];
        int[] totalSum = new int[1];

        // Initialize array
        for (int i = 0; i < 20; i++) {
            num[i] = i + 1;
        }

        // Master Process
        if (rank == 0) {

            // Send data to worker processes
            for (int i = 1; i < size; i++) {
                MPI.COMM_WORLD.Send(num, i * 5, 5, MPI.INT, i, 1);
            }

            // Calculate local sum for rank 0
            for (int i = 0; i < 5; i++) {
                localSum[0] += num[i];
            }

            System.out.println("Local sum at rank 0 is: " + localSum[0]);

            totalSum[0] = localSum[0];

            int[] temp = new int[1];

            // Receive sums from workers
            for (int i = 1; i < size; i++) {
                MPI.COMM_WORLD.Recv(temp, 0, 1, MPI.INT, i, 1);

                System.out.println("Received local sum from rank "
                        + i + " = " + temp[0]);

                totalSum[0] += temp[0];
            }

            System.out.println("Final Sum = " + totalSum[0]);
        }

        // Worker Processes
        else {

            // Receive 5 elements from master
            MPI.COMM_WORLD.Recv(recvArray, 0, 5, MPI.INT, 0, 1);

            // Calculate local sum
            for (int i = 0; i < 5; i++) {
                localSum[0] += recvArray[i];
            }

            System.out.println("Local sum at rank "
                    + rank + " is: " + localSum[0]);

            // Send local sum to master
            MPI.COMM_WORLD.Send(localSum, 0, 1, MPI.INT, 0, 1);
        }

        MPI.Finalize();
    }
}